from django.db import models
from django.contrib import admin


class ImageGallery(models.Model):
    title = models.CharField(max_length=50, blank=True, null=True)
    base_name = models.CharField(max_length=50)
    image_count = models.IntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)
    
    def images_list(self):
        result = []
        for x in range(0, self.image_count):
            if x < 10:
                url = self.base_name + "0" + str(x)
            else:
                url = self.base_name + str(x)
            
            result.append(url)
        
        return result
            
    def thumbnails_list(self):
        result = []
        for x in range(0,self.image_count):
            if x < 10:
                url = self.base_name + "0" + str(x) + "t"
            else:
                url = self.base_name + str(x) + "t"
                
            result.append(url)
        
        return result
    
    def  __str__(self):
        return self.base_name

class ImageGalleryAdmin(admin.ModelAdmin):
    search_fields = ["title"]
    list_display = ["__str__", "title","image_count", "base_name", "created"]
    list_filter = ["base_name"]

# admin.site.register(ImageGallery, ImageGalleryAdmin)