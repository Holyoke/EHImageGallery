from django.http import HttpResponse
from django.shortcuts import render
from imagegallery.models import ImageGallery


def index(request):
    gallery = ImageGallery.objects.get(base_name = "testbasename")
    image_urls = gallery.images_list()
    thumb_urls = gallery.thumbnails_list()
    print image_urls
    ctx = {'image_urls' : image_urls}
    return render(request, 'gallery.html', ctx)

# Create your views here.
