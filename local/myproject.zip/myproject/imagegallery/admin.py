from django.contrib import admin
from imagegallery.models import ImageGallery

# Register your models here.
admin.site.register(ImageGallery)